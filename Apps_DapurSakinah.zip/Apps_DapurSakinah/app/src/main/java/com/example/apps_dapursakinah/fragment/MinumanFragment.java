package com.example.apps_dapursakinah.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.apps_dapursakinah.R;
import com.example.apps_dapursakinah.adapter.AdapterMinuman;
import com.example.apps_dapursakinah.model.DataMinuman;
import com.example.apps_dapursakinah.model.Minuman;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MinumanFragment extends Fragment {
    RecyclerView recyclerView;
    private ArrayList<Minuman> listMinuman;


    public MinumanFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_minuman, container, false);
        recyclerView = view.findViewById(R.id.recycler_minuman);
        listMinuman = new ArrayList<>();
        listMinuman.addAll(DataMinuman.getListData());
        showRecyclerGrid();

        return view;
    }


    private void showRecyclerGrid() {
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        AdapterMinuman gridAdapter = new AdapterMinuman(getContext());
        gridAdapter.setListMinuman(listMinuman);
        recyclerView.setAdapter(gridAdapter);
    }


}
