package com.example.apps_dapursakinah.retrofit;

import com.example.apps_dapursakinah.model.MakananResult;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("makanan")
    Call<MakananResult> getMakanan();
}
