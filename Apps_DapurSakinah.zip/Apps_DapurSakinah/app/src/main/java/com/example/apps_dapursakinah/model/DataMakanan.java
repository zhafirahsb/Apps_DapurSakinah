package com.example.apps_dapursakinah.model;

import java.util.ArrayList;

public class DataMakanan {
    public static String[][] data = new String[][]{
            {"Nasi goreng", "Alat dan bahan Nasi Goreng ","Cara Pembuatan Nasi Goreng", "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Nasi_Goreng_Sosis.jpg/250px-Nasi_Goreng_Sosis.jpg"},
            {"Ayam Penyet","Alat dan Bahan Ayam Penyet","Cara Pembuatan Ayam Penyet","https://selerasa.com/wp-content/uploads/2015/12/images_daging_ayam-goreng.jpg"},
            {"Ayam Goreng","Alat dan Bahan Ayam Goreng","Cara Pembuatan Ayam Goreng","https://selerasa.com/wp-content/uploads/2015/12/images_daging_ayam-goreng.jpg"}

    };

    public static ArrayList<Makanan> getListData(){
        ArrayList<Makanan> list = new ArrayList<>();
        for (String[] aData : data) {
            Makanan makanan = new Makanan();
            makanan.setNama(aData[0]);
            makanan.setAlat(aData[1]);
            makanan.setCaraPembuatan(aData[2]);
            makanan.setPhoto(aData[3]);

            list.add(makanan);
        }

        return list;
    }
}
