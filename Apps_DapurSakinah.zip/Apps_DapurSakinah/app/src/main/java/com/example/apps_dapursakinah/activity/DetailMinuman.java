package com.example.apps_dapursakinah.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.apps_dapursakinah.R;
import com.example.apps_dapursakinah.model.Minuman;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class DetailMinuman extends AppCompatActivity {

    public static final String EXTRA_MINUMAN = "extra_makanan";
    ImageView fotoMinuman;
    TextView namaMinuman,alatBahan,cara;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_minuman);

        fotoMinuman = findViewById(R.id.foto_minuman);
        namaMinuman =findViewById(R.id.nama_minuman);
        alatBahan = findViewById(R.id.alat_bahan_minuman);
        cara = findViewById(R.id.cara_pembuatan2);

        Minuman minuman = getIntent().getParcelableExtra(EXTRA_MINUMAN);

        Picasso.get().load(minuman.getPhoto()).into(fotoMinuman);
        namaMinuman.setText(Objects.requireNonNull(minuman).getNama());
        alatBahan.setText(minuman.getAlat());
        cara.setText(minuman.getCaraPembuatan());
    }
}
