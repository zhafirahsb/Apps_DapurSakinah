package com.example.apps_dapursakinah.fragment;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.apps_dapursakinah.ItemClickSupport;
import com.example.apps_dapursakinah.R;
import com.example.apps_dapursakinah.activity.DetailMakanan;
import com.example.apps_dapursakinah.adapter.AdapterMakanan;
import com.example.apps_dapursakinah.model.DataMakanan;
import com.example.apps_dapursakinah.model.Makanan;
import com.example.apps_dapursakinah.model.MakananModel;
import com.example.apps_dapursakinah.model.MakananResult;
import com.example.apps_dapursakinah.retrofit.ApiInterface;
import com.example.apps_dapursakinah.retrofit.ApiRepository;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class MakananFragment extends Fragment {

    RecyclerView recyclerView;
    private ArrayList<MakananModel> listMakanan;
    public MakananFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_makanan, container, false);
        recyclerView = view.findViewById(R.id.recycler_makanan);
//        listMakanan = new ArrayList<>();
//        listMakanan.addAll(DataMakanan.getListData());
//        showRecyclerGrid();

        return view;
    }

//    private void showRecyclerGrid() {
//        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
//        AdapterMakanan gridAdapter = new AdapterMakanan(getContext());
//        gridAdapter.setListMakanan(listMakanan);
//        recyclerView.setAdapter(gridAdapter);
//    }

    private void clickItemDetail(MakananModel makanan){
        Intent detailActivity = new Intent(getActivity(), DetailMakanan.class);
        detailActivity.putExtra("id_makanan",makanan.getId());
        startActivity(detailActivity);
        getActivity().overridePendingTransition(0,0);
    }

    private void getData(){
        final AdapterMakanan adapterMakanan = new AdapterMakanan(this.getActivity());
        ApiInterface apiInterface = ApiRepository.getUrl().create(ApiInterface.class);
        Call<MakananResult> call = apiInterface.getMakanan();
        call.enqueue(new Callback<MakananResult>() {
            @Override
            public void onResponse(Call<MakananResult> call, Response<MakananResult> response) {
                List<MakananModel> makananList = response.body().getResult();
                adapterMakanan.setListMakanan(makananList);
                reloadView(adapterMakanan,makananList);

            }

            @Override
            public void onFailure(Call<MakananResult> call, Throwable t) {

            }
        });
    }

    public void reloadView(RecyclerView.Adapter adapter, final List<MakananModel> list ){
        recyclerView.setAdapter(adapter);
        ItemClickSupport.addTo(recyclerView).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
            @Override
            public void onItemClicked(RecyclerView recyclerView, final int position, View v) {
                clickItemDetail(list.get(position));
            }
        });
    }
}
