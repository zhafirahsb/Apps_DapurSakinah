package com.example.apps_dapursakinah.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apps_dapursakinah.R;
import com.example.apps_dapursakinah.activity.DetailMakanan;
import com.example.apps_dapursakinah.activity.DetailMinuman;
import com.example.apps_dapursakinah.model.Minuman;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterMinuman extends RecyclerView.Adapter<AdapterMinuman.GridViewHolder>{
    private Context context;
    private ArrayList<Minuman> listMinuman;

    public AdapterMinuman(Context context) {
        this.context = context;
    }

    public ArrayList<Minuman> getListMinuman() {
        return listMinuman;
    }

    public void setListMinuman(ArrayList<Minuman> listMinuman) {
        this.listMinuman = listMinuman;
    }

    @NonNull
    @Override
    public AdapterMinuman.GridViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.minuman, parent, false);
        return new AdapterMinuman.GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AdapterMinuman.GridViewHolder holder, final int position) {
        Picasso.get().load(getListMinuman().get(position).getPhoto()).into(holder.imgPhoto);
//        Glide.with(context)
//                .load(getListMakanan().get(position).getPhoto())
//                .apply(new RequestOptions().override(350, 550))
//                .into(holder.imgPhoto);
        holder.text1.setText(getListMinuman().get(position).getNama());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,holder.text1.getText(),Toast.LENGTH_SHORT).show();
                Minuman minuman = new Minuman();
                minuman.setPhoto(listMinuman.get(position).getPhoto());
                minuman.setNama(listMinuman.get(position).getNama());
                minuman.setAlat(listMinuman.get(position).getAlat());
                minuman.setCaraPembuatan(listMinuman.get(position).getCaraPembuatan());
                Intent intent = new Intent(context, DetailMinuman.class);
                intent.putExtra(DetailMinuman.EXTRA_MINUMAN,minuman);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return getListMinuman().size();
    }

    class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView text1;
        CardView cardView;
        GridViewHolder(View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.minuman);
            text1 = itemView.findViewById(R.id.text2);
            cardView = itemView.findViewById(R.id.card_minuman);
        }
    }
}

