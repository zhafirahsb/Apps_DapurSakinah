package com.example.apps_dapursakinah.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.apps_dapursakinah.R;
import com.example.apps_dapursakinah.model.Makanan;
import com.example.apps_dapursakinah.model.MakananModel;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class DetailMakanan extends AppCompatActivity {

    public static final String EXTRA_MAKANAN = "extra_makanan";
    ImageView fotoMakanan;
    TextView namaMakanan,alatBahan,cara;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_makanan);

        fotoMakanan = findViewById(R.id.foto_makanan);
        namaMakanan =findViewById(R.id.nama_makanan);
        alatBahan = findViewById(R.id.alat_bahan_makanan);
        cara = findViewById(R.id.cara_pembuatan);

        MakananModel makanan = getIntent().getParcelableExtra(EXTRA_MAKANAN);

        Picasso.get().load(makanan.getGambar()).into(fotoMakanan);
        namaMakanan.setText(Objects.requireNonNull(makanan).getNamaMakanan());
        alatBahan.setText(makanan.getResep());
        cara.setText(makanan.getResep());
    }
}
